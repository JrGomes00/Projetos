﻿namespace wfaVendas_Heloisa_Silvio
{
    partial class FrmItemVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmItemVenda));
            this.btnCancelar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnOk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtsubTotal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPrecoUnit = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.nudQuantidade = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDescrição = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.cmbProduto = new Bunifu.Framework.UI.BunifuDropdown();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNumVenda = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantidade)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancelar
            // 
            this.btnCancelar.Activecolor = System.Drawing.Color.DarkViolet;
            this.btnCancelar.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.btnCancelar.BackColor = System.Drawing.Color.DarkViolet;
            this.btnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancelar.BorderRadius = 0;
            this.btnCancelar.ButtonText = "Cancelar";
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.DisabledColor = System.Drawing.Color.Gray;
            this.btnCancelar.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCancelar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Iconimage")));
            this.btnCancelar.Iconimage_right = null;
            this.btnCancelar.Iconimage_right_Selected = null;
            this.btnCancelar.Iconimage_Selected = null;
            this.btnCancelar.IconMarginLeft = 0;
            this.btnCancelar.IconMarginRight = 0;
            this.btnCancelar.IconRightVisible = true;
            this.btnCancelar.IconRightZoom = 0D;
            this.btnCancelar.IconVisible = true;
            this.btnCancelar.IconZoom = 90D;
            this.btnCancelar.IsTab = false;
            this.btnCancelar.Location = new System.Drawing.Point(459, 385);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Normalcolor = System.Drawing.Color.DarkViolet;
            this.btnCancelar.OnHovercolor = System.Drawing.Color.DarkViolet;
            this.btnCancelar.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCancelar.selected = false;
            this.btnCancelar.Size = new System.Drawing.Size(177, 65);
            this.btnCancelar.TabIndex = 77;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Textcolor = System.Drawing.Color.White;
            this.btnCancelar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnOk
            // 
            this.btnOk.Activecolor = System.Drawing.Color.DarkViolet;
            this.btnOk.BackColor = System.Drawing.Color.DarkViolet;
            this.btnOk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOk.BorderRadius = 0;
            this.btnOk.ButtonText = "OK";
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOk.DisabledColor = System.Drawing.Color.Gray;
            this.btnOk.Iconcolor = System.Drawing.Color.Transparent;
            this.btnOk.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnOk.Iconimage")));
            this.btnOk.Iconimage_right = null;
            this.btnOk.Iconimage_right_Selected = null;
            this.btnOk.Iconimage_Selected = null;
            this.btnOk.IconMarginLeft = 0;
            this.btnOk.IconMarginRight = 0;
            this.btnOk.IconRightVisible = true;
            this.btnOk.IconRightZoom = 0D;
            this.btnOk.IconVisible = true;
            this.btnOk.IconZoom = 90D;
            this.btnOk.IsTab = false;
            this.btnOk.Location = new System.Drawing.Point(316, 385);
            this.btnOk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnOk.Name = "btnOk";
            this.btnOk.Normalcolor = System.Drawing.Color.DarkViolet;
            this.btnOk.OnHovercolor = System.Drawing.Color.DarkViolet;
            this.btnOk.OnHoverTextColor = System.Drawing.Color.White;
            this.btnOk.selected = false;
            this.btnOk.Size = new System.Drawing.Size(135, 65);
            this.btnOk.TabIndex = 76;
            this.btnOk.Text = "OK";
            this.btnOk.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOk.Textcolor = System.Drawing.Color.White;
            this.btnOk.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(63, 306);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 21);
            this.label4.TabIndex = 75;
            this.label4.Text = "Sub Total:";
            // 
            // txtsubTotal
            // 
            this.txtsubTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtsubTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtsubTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtsubTotal.HintForeColor = System.Drawing.Color.Empty;
            this.txtsubTotal.HintText = "";
            this.txtsubTotal.isPassword = false;
            this.txtsubTotal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtsubTotal.LineIdleColor = System.Drawing.Color.Gray;
            this.txtsubTotal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtsubTotal.LineThickness = 3;
            this.txtsubTotal.Location = new System.Drawing.Point(170, 295);
            this.txtsubTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtsubTotal.Name = "txtsubTotal";
            this.txtsubTotal.Size = new System.Drawing.Size(164, 44);
            this.txtsubTotal.TabIndex = 74;
            this.txtsubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 21);
            this.label3.TabIndex = 73;
            this.label3.Text = "Preço Unitário:";
            // 
            // txtPrecoUnit
            // 
            this.txtPrecoUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPrecoUnit.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtPrecoUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtPrecoUnit.HintForeColor = System.Drawing.Color.Empty;
            this.txtPrecoUnit.HintText = "";
            this.txtPrecoUnit.isPassword = false;
            this.txtPrecoUnit.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtPrecoUnit.LineIdleColor = System.Drawing.Color.Gray;
            this.txtPrecoUnit.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtPrecoUnit.LineThickness = 3;
            this.txtPrecoUnit.Location = new System.Drawing.Point(170, 216);
            this.txtPrecoUnit.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrecoUnit.Name = "txtPrecoUnit";
            this.txtPrecoUnit.Size = new System.Drawing.Size(164, 44);
            this.txtPrecoUnit.TabIndex = 72;
            this.txtPrecoUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // nudQuantidade
            // 
            this.nudQuantidade.Location = new System.Drawing.Point(170, 161);
            this.nudQuantidade.Name = "nudQuantidade";
            this.nudQuantidade.Size = new System.Drawing.Size(74, 26);
            this.nudQuantidade.TabIndex = 71;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 21);
            this.label2.TabIndex = 70;
            this.label2.Text = "Quantidade:";
            // 
            // txtDescrição
            // 
            this.txtDescrição.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDescrição.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtDescrição.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtDescrição.HintForeColor = System.Drawing.Color.Empty;
            this.txtDescrição.HintText = "";
            this.txtDescrição.isPassword = false;
            this.txtDescrição.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtDescrição.LineIdleColor = System.Drawing.Color.Gray;
            this.txtDescrição.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtDescrição.LineThickness = 3;
            this.txtDescrição.Location = new System.Drawing.Point(255, 80);
            this.txtDescrição.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescrição.Name = "txtDescrição";
            this.txtDescrição.Size = new System.Drawing.Size(381, 44);
            this.txtDescrição.TabIndex = 69;
            this.txtDescrição.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // cmbProduto
            // 
            this.cmbProduto.BackColor = System.Drawing.Color.Transparent;
            this.cmbProduto.BorderRadius = 3;
            this.cmbProduto.ForeColor = System.Drawing.Color.White;
            this.cmbProduto.Items = new string[0];
            this.cmbProduto.Location = new System.Drawing.Point(170, 70);
            this.cmbProduto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbProduto.Name = "cmbProduto";
            this.cmbProduto.NomalColor = System.Drawing.Color.DarkViolet;
            this.cmbProduto.onHoverColor = System.Drawing.Color.DarkViolet;
            this.cmbProduto.selectedIndex = -1;
            this.cmbProduto.Size = new System.Drawing.Size(74, 54);
            this.cmbProduto.TabIndex = 68;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(72, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 21);
            this.label1.TabIndex = 67;
            this.label1.Text = "Produto:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(69, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 21);
            this.label6.TabIndex = 66;
            this.label6.Text = "Venda:";
            // 
            // txtNumVenda
            // 
            this.txtNumVenda.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNumVenda.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtNumVenda.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNumVenda.HintForeColor = System.Drawing.Color.Empty;
            this.txtNumVenda.HintText = "";
            this.txtNumVenda.isPassword = false;
            this.txtNumVenda.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtNumVenda.LineIdleColor = System.Drawing.Color.Gray;
            this.txtNumVenda.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtNumVenda.LineThickness = 3;
            this.txtNumVenda.Location = new System.Drawing.Point(170, -1);
            this.txtNumVenda.Margin = new System.Windows.Forms.Padding(4);
            this.txtNumVenda.Name = "txtNumVenda";
            this.txtNumVenda.Size = new System.Drawing.Size(164, 44);
            this.txtNumVenda.TabIndex = 65;
            this.txtNumVenda.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // FrmItemVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(663, 481);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtsubTotal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPrecoUnit);
            this.Controls.Add(this.nudQuantidade);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDescrição);
            this.Controls.Add(this.cmbProduto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNumVenda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmItemVenda";
            this.Text = "FrmItemVenda";
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantidade)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton btnCancelar;
        private Bunifu.Framework.UI.BunifuFlatButton btnOk;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtsubTotal;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtPrecoUnit;
        private System.Windows.Forms.NumericUpDown nudQuantidade;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtDescrição;
        private Bunifu.Framework.UI.BunifuDropdown cmbProduto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtNumVenda;
    }
}