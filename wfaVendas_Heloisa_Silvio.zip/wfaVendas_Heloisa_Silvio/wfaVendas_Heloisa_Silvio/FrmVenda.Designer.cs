﻿namespace wfaVendas_Heloisa_Silvio
{
    partial class FrmVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmVenda));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.btnPesquisar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCancelar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnGravar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnAlterar = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuMaterialTextbox5 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnExcluir = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnIncluir = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpDataVenda = new Bunifu.Framework.UI.BunifuDatepicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtNumVenda = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbCliente = new Bunifu.Framework.UI.BunifuDropdown();
            this.dtpDataEntrega = new Bunifu.Framework.UI.BunifuDatepicker();
            this.label2 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dgvVendas = new System.Windows.Forms.DataGridView();
            this.bunifuGradientPanel2 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.btnPesquisarItem = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCancelarItem = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnGravarItem = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnAlterarItem = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuMaterialTextbox1 = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btnExcluirItem = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnIncluirItem = new Bunifu.Framework.UI.BunifuFlatButton();
            this.cmbProduto = new Bunifu.Framework.UI.BunifuDropdown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPrecoUnit = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSubTotal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTotal = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.dgvItens = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.nudQuantidade = new System.Windows.Forms.NumericUpDown();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVendas)).BeginInit();
            this.bunifuGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItens)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantidade)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Controls.Add(this.bunifuImageButton3);
            this.panel1.Controls.Add(this.bunifuImageButton2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1526, 53);
            this.panel1.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(53, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(250, 28);
            this.label10.TabIndex = 24;
            this.label10.Text = "Cadastro de vendas";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1478, 12);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(36, 32);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 11;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(1394, 12);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(36, 32);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton3.TabIndex = 20;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuImageButton3.Zoom = 10;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(1436, 12);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(36, 32);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 19;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.btnPesquisar);
            this.bunifuGradientPanel1.Controls.Add(this.btnCancelar);
            this.bunifuGradientPanel1.Controls.Add(this.btnGravar);
            this.bunifuGradientPanel1.Controls.Add(this.btnAlterar);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuMaterialTextbox5);
            this.bunifuGradientPanel1.Controls.Add(this.btnExcluir);
            this.bunifuGradientPanel1.Controls.Add(this.btnIncluir);
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Purple;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.DarkOrchid;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 53);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1526, 74);
            this.bunifuGradientPanel1.TabIndex = 25;
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Activecolor = System.Drawing.Color.Transparent;
            this.btnPesquisar.BackColor = System.Drawing.Color.Transparent;
            this.btnPesquisar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPesquisar.BorderRadius = 0;
            this.btnPesquisar.ButtonText = "Pesquisar";
            this.btnPesquisar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPesquisar.DisabledColor = System.Drawing.Color.Gray;
            this.btnPesquisar.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPesquisar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnPesquisar.Iconimage")));
            this.btnPesquisar.Iconimage_right = null;
            this.btnPesquisar.Iconimage_right_Selected = null;
            this.btnPesquisar.Iconimage_Selected = null;
            this.btnPesquisar.IconMarginLeft = 0;
            this.btnPesquisar.IconMarginRight = 0;
            this.btnPesquisar.IconRightVisible = true;
            this.btnPesquisar.IconRightZoom = 0D;
            this.btnPesquisar.IconVisible = true;
            this.btnPesquisar.IconZoom = 90D;
            this.btnPesquisar.IsTab = false;
            this.btnPesquisar.Location = new System.Drawing.Point(593, 17);
            this.btnPesquisar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Normalcolor = System.Drawing.Color.Transparent;
            this.btnPesquisar.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnPesquisar.OnHoverTextColor = System.Drawing.Color.White;
            this.btnPesquisar.selected = false;
            this.btnPesquisar.Size = new System.Drawing.Size(236, 41);
            this.btnPesquisar.TabIndex = 21;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPesquisar.Textcolor = System.Drawing.Color.White;
            this.btnPesquisar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnCancelar
            // 
            this.btnCancelar.Activecolor = System.Drawing.Color.Transparent;
            this.btnCancelar.BackColor = System.Drawing.Color.Transparent;
            this.btnCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancelar.BorderRadius = 0;
            this.btnCancelar.ButtonText = "Cancelar";
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.DisabledColor = System.Drawing.Color.Gray;
            this.btnCancelar.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCancelar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCancelar.Iconimage")));
            this.btnCancelar.Iconimage_right = null;
            this.btnCancelar.Iconimage_right_Selected = null;
            this.btnCancelar.Iconimage_Selected = null;
            this.btnCancelar.IconMarginLeft = 0;
            this.btnCancelar.IconMarginRight = 0;
            this.btnCancelar.IconRightVisible = true;
            this.btnCancelar.IconRightZoom = 0D;
            this.btnCancelar.IconVisible = true;
            this.btnCancelar.IconZoom = 90D;
            this.btnCancelar.IsTab = false;
            this.btnCancelar.Location = new System.Drawing.Point(1240, 17);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Normalcolor = System.Drawing.Color.Transparent;
            this.btnCancelar.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnCancelar.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCancelar.selected = false;
            this.btnCancelar.Size = new System.Drawing.Size(236, 41);
            this.btnCancelar.TabIndex = 16;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Textcolor = System.Drawing.Color.White;
            this.btnCancelar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnGravar
            // 
            this.btnGravar.Activecolor = System.Drawing.Color.Transparent;
            this.btnGravar.BackColor = System.Drawing.Color.Transparent;
            this.btnGravar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGravar.BorderRadius = 0;
            this.btnGravar.ButtonText = "Gravar";
            this.btnGravar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGravar.DisabledColor = System.Drawing.Color.Gray;
            this.btnGravar.Iconcolor = System.Drawing.Color.Transparent;
            this.btnGravar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnGravar.Iconimage")));
            this.btnGravar.Iconimage_right = null;
            this.btnGravar.Iconimage_right_Selected = null;
            this.btnGravar.Iconimage_Selected = null;
            this.btnGravar.IconMarginLeft = 0;
            this.btnGravar.IconMarginRight = 0;
            this.btnGravar.IconRightVisible = true;
            this.btnGravar.IconRightZoom = 0D;
            this.btnGravar.IconVisible = true;
            this.btnGravar.IconZoom = 90D;
            this.btnGravar.IsTab = false;
            this.btnGravar.Location = new System.Drawing.Point(996, 17);
            this.btnGravar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGravar.Name = "btnGravar";
            this.btnGravar.Normalcolor = System.Drawing.Color.Transparent;
            this.btnGravar.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnGravar.OnHoverTextColor = System.Drawing.Color.White;
            this.btnGravar.selected = false;
            this.btnGravar.Size = new System.Drawing.Size(236, 41);
            this.btnGravar.TabIndex = 15;
            this.btnGravar.Text = "Gravar";
            this.btnGravar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGravar.Textcolor = System.Drawing.Color.White;
            this.btnGravar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnAlterar
            // 
            this.btnAlterar.Activecolor = System.Drawing.Color.Transparent;
            this.btnAlterar.BackColor = System.Drawing.Color.Transparent;
            this.btnAlterar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAlterar.BorderRadius = 0;
            this.btnAlterar.ButtonText = "Alterar";
            this.btnAlterar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterar.DisabledColor = System.Drawing.Color.Gray;
            this.btnAlterar.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAlterar.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAlterar.Iconimage")));
            this.btnAlterar.Iconimage_right = null;
            this.btnAlterar.Iconimage_right_Selected = null;
            this.btnAlterar.Iconimage_Selected = null;
            this.btnAlterar.IconMarginLeft = 0;
            this.btnAlterar.IconMarginRight = 0;
            this.btnAlterar.IconRightVisible = true;
            this.btnAlterar.IconRightZoom = 0D;
            this.btnAlterar.IconVisible = true;
            this.btnAlterar.IconZoom = 90D;
            this.btnAlterar.IsTab = false;
            this.btnAlterar.Location = new System.Drawing.Point(395, 17);
            this.btnAlterar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAlterar.Name = "btnAlterar";
            this.btnAlterar.Normalcolor = System.Drawing.Color.Transparent;
            this.btnAlterar.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnAlterar.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAlterar.selected = false;
            this.btnAlterar.Size = new System.Drawing.Size(236, 41);
            this.btnAlterar.TabIndex = 13;
            this.btnAlterar.Text = "Alterar";
            this.btnAlterar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAlterar.Textcolor = System.Drawing.Color.White;
            this.btnAlterar.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuMaterialTextbox5
            // 
            this.bunifuMaterialTextbox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox5.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifuMaterialTextbox5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox5.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox5.HintText = "";
            this.bunifuMaterialTextbox5.isPassword = false;
            this.bunifuMaterialTextbox5.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox5.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox5.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox5.LineThickness = 3;
            this.bunifuMaterialTextbox5.Location = new System.Drawing.Point(-188, -60);
            this.bunifuMaterialTextbox5.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox5.Name = "bunifuMaterialTextbox5";
            this.bunifuMaterialTextbox5.Size = new System.Drawing.Size(370, 44);
            this.bunifuMaterialTextbox5.TabIndex = 8;
            this.bunifuMaterialTextbox5.Text = "bunifuMaterialTextbox5";
            this.bunifuMaterialTextbox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnExcluir
            // 
            this.btnExcluir.Activecolor = System.Drawing.Color.Transparent;
            this.btnExcluir.BackColor = System.Drawing.Color.Transparent;
            this.btnExcluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExcluir.BorderRadius = 0;
            this.btnExcluir.ButtonText = "Excluir";
            this.btnExcluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluir.DisabledColor = System.Drawing.Color.Gray;
            this.btnExcluir.Iconcolor = System.Drawing.Color.Transparent;
            this.btnExcluir.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnExcluir.Iconimage")));
            this.btnExcluir.Iconimage_right = null;
            this.btnExcluir.Iconimage_right_Selected = null;
            this.btnExcluir.Iconimage_Selected = null;
            this.btnExcluir.IconMarginLeft = 0;
            this.btnExcluir.IconMarginRight = 0;
            this.btnExcluir.IconRightVisible = true;
            this.btnExcluir.IconRightZoom = 0D;
            this.btnExcluir.IconVisible = true;
            this.btnExcluir.IconZoom = 90D;
            this.btnExcluir.IsTab = false;
            this.btnExcluir.Location = new System.Drawing.Point(210, 17);
            this.btnExcluir.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Normalcolor = System.Drawing.Color.Transparent;
            this.btnExcluir.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnExcluir.OnHoverTextColor = System.Drawing.Color.White;
            this.btnExcluir.selected = false;
            this.btnExcluir.Size = new System.Drawing.Size(236, 41);
            this.btnExcluir.TabIndex = 12;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcluir.Textcolor = System.Drawing.Color.White;
            this.btnExcluir.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir.Click += new System.EventHandler(this.BtnExcluir_Click);
            // 
            // btnIncluir
            // 
            this.btnIncluir.Activecolor = System.Drawing.Color.Transparent;
            this.btnIncluir.BackColor = System.Drawing.Color.Transparent;
            this.btnIncluir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIncluir.BorderRadius = 0;
            this.btnIncluir.ButtonText = "Incluir";
            this.btnIncluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIncluir.DisabledColor = System.Drawing.Color.Gray;
            this.btnIncluir.Iconcolor = System.Drawing.Color.Transparent;
            this.btnIncluir.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnIncluir.Iconimage")));
            this.btnIncluir.Iconimage_right = null;
            this.btnIncluir.Iconimage_right_Selected = null;
            this.btnIncluir.Iconimage_Selected = null;
            this.btnIncluir.IconMarginLeft = 0;
            this.btnIncluir.IconMarginRight = 0;
            this.btnIncluir.IconRightVisible = true;
            this.btnIncluir.IconRightZoom = 0D;
            this.btnIncluir.IconVisible = true;
            this.btnIncluir.IconZoom = 90D;
            this.btnIncluir.IsTab = false;
            this.btnIncluir.Location = new System.Drawing.Point(24, 17);
            this.btnIncluir.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnIncluir.Name = "btnIncluir";
            this.btnIncluir.Normalcolor = System.Drawing.Color.Transparent;
            this.btnIncluir.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnIncluir.OnHoverTextColor = System.Drawing.Color.White;
            this.btnIncluir.selected = false;
            this.btnIncluir.Size = new System.Drawing.Size(236, 41);
            this.btnIncluir.TabIndex = 11;
            this.btnIncluir.Text = "Incluir";
            this.btnIncluir.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIncluir.Textcolor = System.Drawing.Color.White;
            this.btnIncluir.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(144, 340);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 21);
            this.label9.TabIndex = 33;
            this.label9.Text = "Obs:";
            // 
            // dtpDataVenda
            // 
            this.dtpDataVenda.BackColor = System.Drawing.Color.DarkViolet;
            this.dtpDataVenda.BorderRadius = 0;
            this.dtpDataVenda.ForeColor = System.Drawing.Color.White;
            this.dtpDataVenda.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataVenda.FormatCustom = null;
            this.dtpDataVenda.Location = new System.Drawing.Point(201, 250);
            this.dtpDataVenda.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dtpDataVenda.Name = "dtpDataVenda";
            this.dtpDataVenda.Size = new System.Drawing.Size(214, 49);
            this.dtpDataVenda.TabIndex = 30;
            this.dtpDataVenda.Value = new System.DateTime(2019, 9, 21, 11, 58, 19, 866);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(92, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 21);
            this.label5.TabIndex = 29;
            this.label5.Text = "Dt. Venda";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(117, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 21);
            this.label6.TabIndex = 27;
            this.label6.Text = "Venda:";
            // 
            // txtNumVenda
            // 
            this.txtNumVenda.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtNumVenda.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtNumVenda.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtNumVenda.HintForeColor = System.Drawing.Color.Empty;
            this.txtNumVenda.HintText = "";
            this.txtNumVenda.isPassword = false;
            this.txtNumVenda.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtNumVenda.LineIdleColor = System.Drawing.Color.Gray;
            this.txtNumVenda.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtNumVenda.LineThickness = 3;
            this.txtNumVenda.Location = new System.Drawing.Point(201, 169);
            this.txtNumVenda.Margin = new System.Windows.Forms.Padding(4);
            this.txtNumVenda.Name = "txtNumVenda";
            this.txtNumVenda.Size = new System.Drawing.Size(164, 44);
            this.txtNumVenda.TabIndex = 26;
            this.txtNumVenda.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(531, 192);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 21);
            this.label1.TabIndex = 35;
            this.label1.Text = "Cliente:";
            // 
            // cmbCliente
            // 
            this.cmbCliente.BackColor = System.Drawing.Color.Transparent;
            this.cmbCliente.BorderRadius = 3;
            this.cmbCliente.ForeColor = System.Drawing.Color.White;
            this.cmbCliente.Items = new string[0];
            this.cmbCliente.Location = new System.Drawing.Point(616, 169);
            this.cmbCliente.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbCliente.Name = "cmbCliente";
            this.cmbCliente.NomalColor = System.Drawing.Color.DarkViolet;
            this.cmbCliente.onHoverColor = System.Drawing.Color.DarkViolet;
            this.cmbCliente.selectedIndex = -1;
            this.cmbCliente.Size = new System.Drawing.Size(506, 54);
            this.cmbCliente.TabIndex = 36;
            // 
            // dtpDataEntrega
            // 
            this.dtpDataEntrega.BackColor = System.Drawing.Color.DarkViolet;
            this.dtpDataEntrega.BorderRadius = 0;
            this.dtpDataEntrega.ForeColor = System.Drawing.Color.White;
            this.dtpDataEntrega.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDataEntrega.FormatCustom = null;
            this.dtpDataEntrega.Location = new System.Drawing.Point(616, 250);
            this.dtpDataEntrega.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dtpDataEntrega.Name = "dtpDataEntrega";
            this.dtpDataEntrega.Size = new System.Drawing.Size(214, 49);
            this.dtpDataEntrega.TabIndex = 38;
            this.dtpDataEntrega.Value = new System.DateTime(2019, 9, 21, 11, 58, 19, 866);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(507, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 21);
            this.label2.TabIndex = 37;
            this.label2.Text = "Dt. Entrega";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(200, 338);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(921, 143);
            this.richTextBox1.TabIndex = 39;
            this.richTextBox1.Text = "";
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.DarkViolet;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Todos";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton1.Iconimage")));
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(1172, 432);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.DarkViolet;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.DarkViolet;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(150, 49);
            this.bunifuFlatButton1.TabIndex = 40;
            this.bunifuFlatButton1.Text = "Todos";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dgvVendas
            // 
            this.dgvVendas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVendas.Location = new System.Drawing.Point(12, 489);
            this.dgvVendas.Name = "dgvVendas";
            this.dgvVendas.RowHeadersWidth = 62;
            this.dgvVendas.RowTemplate.Height = 28;
            this.dgvVendas.Size = new System.Drawing.Size(1464, 175);
            this.dgvVendas.TabIndex = 41;
            // 
            // bunifuGradientPanel2
            // 
            this.bunifuGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel2.BackgroundImage")));
            this.bunifuGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel2.Controls.Add(this.btnPesquisarItem);
            this.bunifuGradientPanel2.Controls.Add(this.btnCancelarItem);
            this.bunifuGradientPanel2.Controls.Add(this.btnGravarItem);
            this.bunifuGradientPanel2.Controls.Add(this.btnAlterarItem);
            this.bunifuGradientPanel2.Controls.Add(this.bunifuMaterialTextbox1);
            this.bunifuGradientPanel2.Controls.Add(this.btnExcluirItem);
            this.bunifuGradientPanel2.Controls.Add(this.btnIncluirItem);
            this.bunifuGradientPanel2.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bunifuGradientPanel2.GradientBottomRight = System.Drawing.Color.Purple;
            this.bunifuGradientPanel2.GradientTopLeft = System.Drawing.Color.Blue;
            this.bunifuGradientPanel2.GradientTopRight = System.Drawing.Color.DarkOrchid;
            this.bunifuGradientPanel2.Location = new System.Drawing.Point(0, 670);
            this.bunifuGradientPanel2.Name = "bunifuGradientPanel2";
            this.bunifuGradientPanel2.Quality = 10;
            this.bunifuGradientPanel2.Size = new System.Drawing.Size(1526, 74);
            this.bunifuGradientPanel2.TabIndex = 42;
            // 
            // btnPesquisarItem
            // 
            this.btnPesquisarItem.Activecolor = System.Drawing.Color.Transparent;
            this.btnPesquisarItem.BackColor = System.Drawing.Color.Transparent;
            this.btnPesquisarItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPesquisarItem.BorderRadius = 0;
            this.btnPesquisarItem.ButtonText = "Pesquisar";
            this.btnPesquisarItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPesquisarItem.DisabledColor = System.Drawing.Color.Gray;
            this.btnPesquisarItem.Iconcolor = System.Drawing.Color.Transparent;
            this.btnPesquisarItem.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnPesquisarItem.Iconimage")));
            this.btnPesquisarItem.Iconimage_right = null;
            this.btnPesquisarItem.Iconimage_right_Selected = null;
            this.btnPesquisarItem.Iconimage_Selected = null;
            this.btnPesquisarItem.IconMarginLeft = 0;
            this.btnPesquisarItem.IconMarginRight = 0;
            this.btnPesquisarItem.IconRightVisible = true;
            this.btnPesquisarItem.IconRightZoom = 0D;
            this.btnPesquisarItem.IconVisible = true;
            this.btnPesquisarItem.IconZoom = 90D;
            this.btnPesquisarItem.IsTab = false;
            this.btnPesquisarItem.Location = new System.Drawing.Point(593, 17);
            this.btnPesquisarItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnPesquisarItem.Name = "btnPesquisarItem";
            this.btnPesquisarItem.Normalcolor = System.Drawing.Color.Transparent;
            this.btnPesquisarItem.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnPesquisarItem.OnHoverTextColor = System.Drawing.Color.White;
            this.btnPesquisarItem.selected = false;
            this.btnPesquisarItem.Size = new System.Drawing.Size(236, 41);
            this.btnPesquisarItem.TabIndex = 21;
            this.btnPesquisarItem.Text = "Pesquisar";
            this.btnPesquisarItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPesquisarItem.Textcolor = System.Drawing.Color.White;
            this.btnPesquisarItem.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnCancelarItem
            // 
            this.btnCancelarItem.Activecolor = System.Drawing.Color.Transparent;
            this.btnCancelarItem.BackColor = System.Drawing.Color.Transparent;
            this.btnCancelarItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancelarItem.BorderRadius = 0;
            this.btnCancelarItem.ButtonText = "Cancelar";
            this.btnCancelarItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelarItem.DisabledColor = System.Drawing.Color.Gray;
            this.btnCancelarItem.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCancelarItem.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCancelarItem.Iconimage")));
            this.btnCancelarItem.Iconimage_right = null;
            this.btnCancelarItem.Iconimage_right_Selected = null;
            this.btnCancelarItem.Iconimage_Selected = null;
            this.btnCancelarItem.IconMarginLeft = 0;
            this.btnCancelarItem.IconMarginRight = 0;
            this.btnCancelarItem.IconRightVisible = true;
            this.btnCancelarItem.IconRightZoom = 0D;
            this.btnCancelarItem.IconVisible = true;
            this.btnCancelarItem.IconZoom = 90D;
            this.btnCancelarItem.IsTab = false;
            this.btnCancelarItem.Location = new System.Drawing.Point(1240, 17);
            this.btnCancelarItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelarItem.Name = "btnCancelarItem";
            this.btnCancelarItem.Normalcolor = System.Drawing.Color.Transparent;
            this.btnCancelarItem.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnCancelarItem.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCancelarItem.selected = false;
            this.btnCancelarItem.Size = new System.Drawing.Size(236, 41);
            this.btnCancelarItem.TabIndex = 16;
            this.btnCancelarItem.Text = "Cancelar";
            this.btnCancelarItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelarItem.Textcolor = System.Drawing.Color.White;
            this.btnCancelarItem.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnGravarItem
            // 
            this.btnGravarItem.Activecolor = System.Drawing.Color.Transparent;
            this.btnGravarItem.BackColor = System.Drawing.Color.Transparent;
            this.btnGravarItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGravarItem.BorderRadius = 0;
            this.btnGravarItem.ButtonText = "Gravar";
            this.btnGravarItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGravarItem.DisabledColor = System.Drawing.Color.Gray;
            this.btnGravarItem.Iconcolor = System.Drawing.Color.Transparent;
            this.btnGravarItem.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnGravarItem.Iconimage")));
            this.btnGravarItem.Iconimage_right = null;
            this.btnGravarItem.Iconimage_right_Selected = null;
            this.btnGravarItem.Iconimage_Selected = null;
            this.btnGravarItem.IconMarginLeft = 0;
            this.btnGravarItem.IconMarginRight = 0;
            this.btnGravarItem.IconRightVisible = true;
            this.btnGravarItem.IconRightZoom = 0D;
            this.btnGravarItem.IconVisible = true;
            this.btnGravarItem.IconZoom = 90D;
            this.btnGravarItem.IsTab = false;
            this.btnGravarItem.Location = new System.Drawing.Point(996, 17);
            this.btnGravarItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGravarItem.Name = "btnGravarItem";
            this.btnGravarItem.Normalcolor = System.Drawing.Color.Transparent;
            this.btnGravarItem.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnGravarItem.OnHoverTextColor = System.Drawing.Color.White;
            this.btnGravarItem.selected = false;
            this.btnGravarItem.Size = new System.Drawing.Size(236, 41);
            this.btnGravarItem.TabIndex = 15;
            this.btnGravarItem.Text = "Gravar";
            this.btnGravarItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGravarItem.Textcolor = System.Drawing.Color.White;
            this.btnGravarItem.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnAlterarItem
            // 
            this.btnAlterarItem.Activecolor = System.Drawing.Color.Transparent;
            this.btnAlterarItem.BackColor = System.Drawing.Color.Transparent;
            this.btnAlterarItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAlterarItem.BorderRadius = 0;
            this.btnAlterarItem.ButtonText = "Alterar";
            this.btnAlterarItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAlterarItem.DisabledColor = System.Drawing.Color.Gray;
            this.btnAlterarItem.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAlterarItem.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAlterarItem.Iconimage")));
            this.btnAlterarItem.Iconimage_right = null;
            this.btnAlterarItem.Iconimage_right_Selected = null;
            this.btnAlterarItem.Iconimage_Selected = null;
            this.btnAlterarItem.IconMarginLeft = 0;
            this.btnAlterarItem.IconMarginRight = 0;
            this.btnAlterarItem.IconRightVisible = true;
            this.btnAlterarItem.IconRightZoom = 0D;
            this.btnAlterarItem.IconVisible = true;
            this.btnAlterarItem.IconZoom = 90D;
            this.btnAlterarItem.IsTab = false;
            this.btnAlterarItem.Location = new System.Drawing.Point(395, 17);
            this.btnAlterarItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAlterarItem.Name = "btnAlterarItem";
            this.btnAlterarItem.Normalcolor = System.Drawing.Color.Transparent;
            this.btnAlterarItem.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnAlterarItem.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAlterarItem.selected = false;
            this.btnAlterarItem.Size = new System.Drawing.Size(236, 41);
            this.btnAlterarItem.TabIndex = 13;
            this.btnAlterarItem.Text = "Alterar";
            this.btnAlterarItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAlterarItem.Textcolor = System.Drawing.Color.White;
            this.btnAlterarItem.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuMaterialTextbox1
            // 
            this.bunifuMaterialTextbox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuMaterialTextbox1.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.bunifuMaterialTextbox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuMaterialTextbox1.HintForeColor = System.Drawing.Color.Empty;
            this.bunifuMaterialTextbox1.HintText = "";
            this.bunifuMaterialTextbox1.isPassword = false;
            this.bunifuMaterialTextbox1.LineFocusedColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineIdleColor = System.Drawing.Color.Gray;
            this.bunifuMaterialTextbox1.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.bunifuMaterialTextbox1.LineThickness = 3;
            this.bunifuMaterialTextbox1.Location = new System.Drawing.Point(-188, -60);
            this.bunifuMaterialTextbox1.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuMaterialTextbox1.Name = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.Size = new System.Drawing.Size(370, 44);
            this.bunifuMaterialTextbox1.TabIndex = 8;
            this.bunifuMaterialTextbox1.Text = "bunifuMaterialTextbox1";
            this.bunifuMaterialTextbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btnExcluirItem
            // 
            this.btnExcluirItem.Activecolor = System.Drawing.Color.Transparent;
            this.btnExcluirItem.BackColor = System.Drawing.Color.Transparent;
            this.btnExcluirItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExcluirItem.BorderRadius = 0;
            this.btnExcluirItem.ButtonText = "Excluir";
            this.btnExcluirItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExcluirItem.DisabledColor = System.Drawing.Color.Gray;
            this.btnExcluirItem.Iconcolor = System.Drawing.Color.Transparent;
            this.btnExcluirItem.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnExcluirItem.Iconimage")));
            this.btnExcluirItem.Iconimage_right = null;
            this.btnExcluirItem.Iconimage_right_Selected = null;
            this.btnExcluirItem.Iconimage_Selected = null;
            this.btnExcluirItem.IconMarginLeft = 0;
            this.btnExcluirItem.IconMarginRight = 0;
            this.btnExcluirItem.IconRightVisible = true;
            this.btnExcluirItem.IconRightZoom = 0D;
            this.btnExcluirItem.IconVisible = true;
            this.btnExcluirItem.IconZoom = 90D;
            this.btnExcluirItem.IsTab = false;
            this.btnExcluirItem.Location = new System.Drawing.Point(210, 17);
            this.btnExcluirItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExcluirItem.Name = "btnExcluirItem";
            this.btnExcluirItem.Normalcolor = System.Drawing.Color.Transparent;
            this.btnExcluirItem.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnExcluirItem.OnHoverTextColor = System.Drawing.Color.White;
            this.btnExcluirItem.selected = false;
            this.btnExcluirItem.Size = new System.Drawing.Size(236, 41);
            this.btnExcluirItem.TabIndex = 12;
            this.btnExcluirItem.Text = "Excluir";
            this.btnExcluirItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExcluirItem.Textcolor = System.Drawing.Color.White;
            this.btnExcluirItem.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnIncluirItem
            // 
            this.btnIncluirItem.Activecolor = System.Drawing.Color.Transparent;
            this.btnIncluirItem.BackColor = System.Drawing.Color.Transparent;
            this.btnIncluirItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnIncluirItem.BorderRadius = 0;
            this.btnIncluirItem.ButtonText = "Incluir";
            this.btnIncluirItem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIncluirItem.DisabledColor = System.Drawing.Color.Gray;
            this.btnIncluirItem.Iconcolor = System.Drawing.Color.Transparent;
            this.btnIncluirItem.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnIncluirItem.Iconimage")));
            this.btnIncluirItem.Iconimage_right = null;
            this.btnIncluirItem.Iconimage_right_Selected = null;
            this.btnIncluirItem.Iconimage_Selected = null;
            this.btnIncluirItem.IconMarginLeft = 0;
            this.btnIncluirItem.IconMarginRight = 0;
            this.btnIncluirItem.IconRightVisible = true;
            this.btnIncluirItem.IconRightZoom = 0D;
            this.btnIncluirItem.IconVisible = true;
            this.btnIncluirItem.IconZoom = 90D;
            this.btnIncluirItem.IsTab = false;
            this.btnIncluirItem.Location = new System.Drawing.Point(24, 17);
            this.btnIncluirItem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnIncluirItem.Name = "btnIncluirItem";
            this.btnIncluirItem.Normalcolor = System.Drawing.Color.Transparent;
            this.btnIncluirItem.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnIncluirItem.OnHoverTextColor = System.Drawing.Color.White;
            this.btnIncluirItem.selected = false;
            this.btnIncluirItem.Size = new System.Drawing.Size(236, 41);
            this.btnIncluirItem.TabIndex = 11;
            this.btnIncluirItem.Text = "Incluir";
            this.btnIncluirItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIncluirItem.Textcolor = System.Drawing.Color.White;
            this.btnIncluirItem.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // cmbProduto
            // 
            this.cmbProduto.BackColor = System.Drawing.Color.Transparent;
            this.cmbProduto.BorderRadius = 3;
            this.cmbProduto.ForeColor = System.Drawing.Color.White;
            this.cmbProduto.Items = new string[0];
            this.cmbProduto.Location = new System.Drawing.Point(121, 768);
            this.cmbProduto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbProduto.Name = "cmbProduto";
            this.cmbProduto.NomalColor = System.Drawing.Color.DarkViolet;
            this.cmbProduto.onHoverColor = System.Drawing.Color.DarkViolet;
            this.cmbProduto.selectedIndex = -1;
            this.cmbProduto.Size = new System.Drawing.Size(506, 54);
            this.cmbProduto.TabIndex = 44;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 783);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 21);
            this.label3.TabIndex = 43;
            this.label3.Text = "Produto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(868, 753);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 21);
            this.label4.TabIndex = 46;
            this.label4.Text = "Preço Unitário:";
            // 
            // txtPrecoUnit
            // 
            this.txtPrecoUnit.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPrecoUnit.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtPrecoUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtPrecoUnit.HintForeColor = System.Drawing.Color.Empty;
            this.txtPrecoUnit.HintText = "";
            this.txtPrecoUnit.isPassword = false;
            this.txtPrecoUnit.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtPrecoUnit.LineIdleColor = System.Drawing.Color.Gray;
            this.txtPrecoUnit.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtPrecoUnit.LineThickness = 3;
            this.txtPrecoUnit.Location = new System.Drawing.Point(872, 778);
            this.txtPrecoUnit.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrecoUnit.Name = "txtPrecoUnit";
            this.txtPrecoUnit.Size = new System.Drawing.Size(164, 44);
            this.txtPrecoUnit.TabIndex = 45;
            this.txtPrecoUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1093, 753);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 21);
            this.label7.TabIndex = 48;
            this.label7.Text = "Sub Total:";
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSubTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtSubTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtSubTotal.HintForeColor = System.Drawing.Color.Empty;
            this.txtSubTotal.HintText = "";
            this.txtSubTotal.isPassword = false;
            this.txtSubTotal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtSubTotal.LineIdleColor = System.Drawing.Color.Gray;
            this.txtSubTotal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtSubTotal.LineThickness = 3;
            this.txtSubTotal.Location = new System.Drawing.Point(1097, 778);
            this.txtSubTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.Size = new System.Drawing.Size(164, 44);
            this.txtSubTotal.TabIndex = 47;
            this.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1308, 753);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 21);
            this.label8.TabIndex = 50;
            this.label8.Text = "Total:";
            // 
            // txtTotal
            // 
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotal.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTotal.HintForeColor = System.Drawing.Color.Empty;
            this.txtTotal.HintText = "";
            this.txtTotal.isPassword = false;
            this.txtTotal.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTotal.LineIdleColor = System.Drawing.Color.Gray;
            this.txtTotal.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTotal.LineThickness = 3;
            this.txtTotal.Location = new System.Drawing.Point(1312, 778);
            this.txtTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(164, 44);
            this.txtTotal.TabIndex = 49;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // dgvItens
            // 
            this.dgvItens.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItens.Location = new System.Drawing.Point(12, 848);
            this.dgvItens.Name = "dgvItens";
            this.dgvItens.RowHeadersWidth = 62;
            this.dgvItens.RowTemplate.Height = 28;
            this.dgvItens.Size = new System.Drawing.Size(1464, 175);
            this.dgvItens.TabIndex = 51;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(647, 753);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(123, 21);
            this.label11.TabIndex = 52;
            this.label11.Text = "Quantidade:";
            // 
            // nudQuantidade
            // 
            this.nudQuantidade.Location = new System.Drawing.Point(651, 796);
            this.nudQuantidade.Name = "nudQuantidade";
            this.nudQuantidade.Size = new System.Drawing.Size(120, 26);
            this.nudQuantidade.TabIndex = 53;
            // 
            // FrmVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1526, 1046);
            this.Controls.Add(this.nudQuantidade);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dgvItens);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPrecoUnit);
            this.Controls.Add(this.cmbProduto);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bunifuGradientPanel2);
            this.Controls.Add(this.dgvVendas);
            this.Controls.Add(this.bunifuFlatButton1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.dtpDataEntrega);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbCliente);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.dtpDataVenda);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNumVenda);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmVenda";
            this.Text = "FrmCompra";
            this.Load += new System.EventHandler(this.FrmCompra_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvVendas)).EndInit();
            this.bunifuGradientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItens)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantidade)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label10;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuFlatButton btnPesquisar;
        private Bunifu.Framework.UI.BunifuFlatButton btnCancelar;
        private Bunifu.Framework.UI.BunifuFlatButton btnGravar;
        private Bunifu.Framework.UI.BunifuFlatButton btnAlterar;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox5;
        private Bunifu.Framework.UI.BunifuFlatButton btnExcluir;
        private Bunifu.Framework.UI.BunifuFlatButton btnIncluir;
        private System.Windows.Forms.Label label9;
        private Bunifu.Framework.UI.BunifuDatepicker dtpDataVenda;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtNumVenda;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuDropdown cmbCliente;
        private Bunifu.Framework.UI.BunifuDatepicker dtpDataEntrega;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.DataGridView dgvVendas;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel2;
        private Bunifu.Framework.UI.BunifuFlatButton btnPesquisarItem;
        private Bunifu.Framework.UI.BunifuFlatButton btnCancelarItem;
        private Bunifu.Framework.UI.BunifuFlatButton btnGravarItem;
        private Bunifu.Framework.UI.BunifuFlatButton btnAlterarItem;
        private Bunifu.Framework.UI.BunifuMaterialTextbox bunifuMaterialTextbox1;
        private Bunifu.Framework.UI.BunifuFlatButton btnExcluirItem;
        private Bunifu.Framework.UI.BunifuFlatButton btnIncluirItem;
        private Bunifu.Framework.UI.BunifuDropdown cmbProduto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtPrecoUnit;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtSubTotal;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTotal;
        private System.Windows.Forms.DataGridView dgvItens;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown nudQuantidade;
    }
}